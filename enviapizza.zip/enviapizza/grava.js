
function grava(){
    
var nomepizza = document.getElementById('form05-quantadae');
var precopizza = document.getElementById('form05-r-preo');
var descpizza = document.getElementById('form05-descrio');
var fotopizza = document.getElementById('form05-foto');

var status = document.getElementById('status');


var nedb = require('nedb');
var db = new nedb({filename: 'banco.db', autoload: true});

var pizza = {
	nome: nomepizza,
	preco: precopizza,
	email: descpizza,
	foto: fotopizza
};


    db.insert(pizza, function(err){
        if(err)return console.log(err); //caso ocorrer algum erro
       
        status.innerHTML = "Deu Certo essa porra";
       });

}
